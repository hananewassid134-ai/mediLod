import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'medilog.settings')
django.setup()

from reservations.models import Reservation

print(f"{'ID':<5} | {'Service':<20} | {'Receipt':<50}")
print("-" * 80)
for res in Reservation.objects.all().order_by('-id')[:10]:
    print(f"{res.id:<5} | {res.service_name:<20} | {str(res.receipt):<50}")
