import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'medilog.settings')
django.setup()

from tracking.models import Reservation

res = Reservation.objects.filter(id=42).first()
if res:
    print(f"ID: {res.id}")
    print(f"Status: {res.status}")
    print(f"Patient Lat/Lng: {res.patient_lat}, {res.patient_lng}")
    print(f"Doctor Lat/Lng: {res.doctor_lat}, {res.doctor_lng}")
    print(f"Courier Lat/Lng: {res.delivery_lat}, {res.delivery_lng}")
else:
    print("Reservation 42 not found")
