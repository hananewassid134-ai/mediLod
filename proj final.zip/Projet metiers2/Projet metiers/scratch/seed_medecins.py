import os
import sys
import django

sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'medilog.settings')
django.setup()

from django.contrib.auth.models import User
from users.models import UserProfile, Medecin

def seed_medecins():
    doctors = User.objects.filter(profile__role='medecin')
    for doc in doctors:
        if not hasattr(doc, 'medecin_profile'):
            Medecin.objects.create(
                user=doc,
                nom=doc.last_name or doc.username,
                prenom=doc.first_name or "",
                specialite=doc.profile.specialite or "Généraliste",
                telephone=doc.profile.telephone or "0000000000",
                adresse=doc.profile.adresse or "Non spécifiée",
                email=doc.email or f"{doc.username}@medilog.ma"
            )
            print(f"Created Medecin for {doc.username}")

if __name__ == "__main__":
    seed_medecins()
