"""
Seed script: Assign realistic Casablanca GPS positions to all users.
Run: python manage.py shell < scratch/seed_positions.py
"""
import os, sys, django
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'medilog.settings')
django.setup()

from users.models import UserProfile, Medecin

# Positions réalistes à Casablanca
PATIENT_POSITIONS = [
    (33.5831, -7.6314, "Maarif"),
    (33.5953, -7.6712, "Ain Diab"),
    (33.5731, -7.5893, "Hay Mohammadi"),
    (33.5622, -7.6125, "Derb Sultan"),
    (33.5974, -7.6189, "Bourgogne"),
    (33.5485, -7.6731, "Sidi Maarouf"),
    (33.6012, -7.5921, "Ain Sebaa"),
    (33.5762, -7.6541, "Californie"),
    (33.5889, -7.6423, "Gauthier"),
    (33.5693, -7.6048, "Habous"),
]

MEDECIN_POSITIONS = [
    (33.5891, -7.6032, "CHU Ibn Rochd"),
    (33.5728, -7.6204, "Clinique Ghandi"),
    (33.5812, -7.6385, "Clinique Zerktouni"),
    (33.5965, -7.6143, "Clinique Badr"),
    (33.5847, -7.6290, "Polyclinique Atlas"),
    (33.5555, -7.6098, "Hôpital Moulay Youssef"),
    (33.5934, -7.6456, "Centre Médical CIL"),
    (33.5776, -7.6167, "Cabinet Derb Omar"),
]

# Assign positions to patients
patients = UserProfile.objects.filter(role='patient')
for i, p in enumerate(patients):
    pos = PATIENT_POSITIONS[i % len(PATIENT_POSITIONS)]
    p.latitude = pos[0]
    p.longitude = pos[1]
    p.save()
    print(f"✅ Patient '{p.user.username}' → {pos[2]} ({pos[0]}, {pos[1]})")

# Assign positions to medecins
medecins = Medecin.objects.all()
for i, m in enumerate(medecins):
    pos = MEDECIN_POSITIONS[i % len(MEDECIN_POSITIONS)]
    m.latitude = pos[0]
    m.longitude = pos[1]
    m.save()
    print(f"✅ Dr. {m.nom} → {pos[2]} ({pos[0]}, {pos[1]})")

print(f"\n🗺️ Positions assignées: {patients.count()} patients, {medecins.count()} médecins")
